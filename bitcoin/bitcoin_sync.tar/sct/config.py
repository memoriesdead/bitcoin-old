#!/usr/bin/env python3
"""
SCT Configuration - Statistical Certainty Trading Parameters

RenTech-style thresholds for mathematical certainty.
"""

from dataclasses import dataclass, field
from typing import Optional, Dict


@dataclass
class SCTConfig:
    """
    Configuration for Statistical Certainty Trading.

    Key thresholds based on Renaissance Technologies methodology:
    - 50.75% win rate = covers fees + slippage + profit
    - 99% confidence = only 1% chance of being wrong
    """

    # Core thresholds
    min_win_rate: float = 0.5075      # RenTech threshold (50.75%)
    confidence_level: float = 0.99    # 99% confidence
    min_trades: int = 25              # Minimum sample size

    # Position sizing
    kelly_fraction: float = 0.25      # Quarter-Kelly for safety
    max_position_pct: float = 0.05    # 5% max per trade
    min_position_pct: float = 0.001   # 0.1% minimum

    # Risk parameters
    risk_reward_ratio: float = 1.0    # 1:1 default
    max_drawdown_pct: float = 0.20    # 20% max drawdown

    # Z-scores for common confidence levels (pre-computed)
    # Avoids scipy dependency
    Z_SCORES = {
        0.90: 1.645,
        0.95: 1.960,
        0.99: 2.576,
        0.999: 3.291,
    }

    # Per-exchange max leverage (from official docs Dec 2024)
    exchange_leverage: Dict[str, int] = field(default_factory=lambda: {
        'mexc': 500,        # MEXC max 500x futures
        'binance': 125,     # Binance max 125x (20x new users)
        'bybit': 100,       # Bybit max 100x
        'kraken': 50,       # Kraken max 50x
        'coinbase': 10,     # Coinbase max 10x (US regulated)
        'gemini': 5,        # Gemini 5x US, 100x non-US
        'bitstamp': 10,     # Bitstamp 10x max
        'crypto.com': 20,   # Crypto.com max 20x
        'default': 10       # Conservative default
    })

    def get_leverage(self, exchange: str) -> int:
        """Get max leverage for exchange."""
        return self.exchange_leverage.get(exchange.lower(), self.exchange_leverage['default'])

    def get_z_score(self, confidence: Optional[float] = None) -> float:
        """Get z-score for confidence level."""
        conf = confidence or self.confidence_level
        return self.Z_SCORES.get(conf, 2.576)


# Default config singleton
_config: Optional[SCTConfig] = None


def get_config() -> SCTConfig:
    """Get or create default configuration."""
    global _config
    if _config is None:
        _config = SCTConfig()
    return _config


def set_config(config: SCTConfig) -> None:
    """Set custom configuration."""
    global _config
    _config = config
