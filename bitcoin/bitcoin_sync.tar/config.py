#!/usr/bin/env python3
"""CONFIGURATION - Single source of truth"""

import os
from dataclasses import dataclass, field
from typing import Set
from pathlib import Path


def _get_data_dir() -> Path:
    if os.path.exists('/root/sovereign'):
        return Path('/root/sovereign')
    return Path(__file__).parent.parent / 'data'


@dataclass
class TradingConfig:
    # === CORRELATION ===
    # HIGH LEVERAGE RULE: Only trade 100% win rate patterns
    # If going all-in with leverage, must be certain
    min_correlation: float = 0.0    # Data shows winning patterns have varied correlation
    min_sample_size: int = 30       # Need statistical significance
    min_win_rate: float = 1.0       # 100% - no losses allowed with high leverage
    correlation_window_minutes: int = 5

    # === POSITION ===
    # ALL-IN MODE: 100% win rate = max leverage allowed
    # Only valid if min_win_rate = 1.0 (no losses)
    initial_capital: float = 100.0
    max_leverage: int = 100           # High leverage for 100% patterns
    max_positions: int = 4            # Multiple positions OK if 100% win
    position_size_pct: float = 0.25   # 25% per position

    # Per-exchange max leverage (from official docs)
    exchange_leverage: dict = field(default_factory=lambda: {
        'coinbase': 10, 'kraken': 50, 'bitstamp': 5, 'gemini': 100, 'crypto.com': 20
    })

    # === EXIT ===
    # DATA FINDING: 5 min too short, trades timeout before move
    # Increase to 1 hour, let thesis play out
    exit_timeout_seconds: float = 3600.0  # 1 hour (was 5 min)
    stop_loss_pct: float = 0.01           # 1%
    take_profit_pct: float = 0.02         # 2%

    # === EXCHANGES ===
    tradeable_exchanges: Set[str] = field(default_factory=lambda: {
        'coinbase', 'kraken', 'bitstamp', 'gemini', 'crypto.com'
    })
    exchange_fees: dict = field(default_factory=lambda: {
        'coinbase': 0.006, 'kraken': 0.0026, 'bitstamp': 0.005,
        'gemini': 0.004, 'crypto.com': 0.004, 'binance': 0.001, 'default': 0.005
    })

    # === FLOW ===
    # DATA FINDING: Small flows don't move price, filter for large flows
    min_flow_btc: float = 10.0  # Only trade flows > 10 BTC (was 0)
    flow_buckets: tuple = ((0,1),(1,5),(5,10),(10,50),(50,100),(100,500),(500,float('inf')))

    # === PATHS ===
    data_dir: Path = field(default_factory=_get_data_dir)

    @property
    def correlation_db_path(self) -> str:
        return str(self.data_dir / 'correlation.db')

    @property
    def addresses_db_path(self) -> str:
        return str(self.data_dir / 'walletexplorer_addresses.db')

    @property
    def trades_db_path(self) -> str:
        return str(self.data_dir / 'trades.db')

    @property
    def cpp_runner_path(self) -> str:
        return '/root/sovereign/cpp_runner/build/blockchain_runner' if os.path.exists('/root/sovereign') else ''

    def get_fee(self, exchange: str) -> float:
        return self.exchange_fees.get(exchange, self.exchange_fees['default'])

    def get_bucket(self, flow_btc: float) -> tuple:
        for low, high in self.flow_buckets:
            if low <= flow_btc < high:
                return (low, high)
        return self.flow_buckets[-1]

    def is_tradeable(self, exchange: str) -> bool:
        return exchange.lower() in self.tradeable_exchanges

    def get_leverage(self, exchange: str) -> int:
        """Get max leverage for exchange (from official docs)."""
        return self.exchange_leverage.get(exchange.lower(), self.max_leverage)


CONFIG = TradingConfig()

def get_config() -> TradingConfig:
    return CONFIG
