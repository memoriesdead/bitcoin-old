#!/usr/bin/env python3
"""
HQT Configuration - Deterministic Trading Parameters

Only trade when: spread > (fees + slippage)
This guarantees profit (100% win rate).
"""

from dataclasses import dataclass, field
from typing import Dict, List


@dataclass
class HQTConfig:
    """High Quality Trades configuration."""

    # === DETERMINISTIC RULES ===
    # Only trade when guaranteed profit
    min_spread_pct: float = 0.50        # Min 0.5% spread to cover all costs
    min_profit_usd: float = 5.0         # Min $5 profit per trade
    max_latency_ms: int = 100           # Max acceptable execution latency

    # === EXCHANGES ===
    # Tier 1 USA exchanges for legal compliance
    exchanges: List[str] = field(default_factory=lambda: [
        'kraken', 'coinbase', 'bitstamp', 'gemini'
    ])

    # Taker fees (we pay to take liquidity) - from exchange docs
    taker_fees: Dict[str, float] = field(default_factory=lambda: {
        'kraken': 0.0026,       # 0.26%
        'coinbase': 0.006,      # 0.60%
        'bitstamp': 0.005,      # 0.50%
        'gemini': 0.004,        # 0.40%
        'binance': 0.001,       # 0.10%
        'bybit': 0.001,         # 0.10%
    })

    # Maker fees (we provide liquidity)
    maker_fees: Dict[str, float] = field(default_factory=lambda: {
        'kraken': 0.0016,       # 0.16%
        'coinbase': 0.004,      # 0.40%
        'bitstamp': 0.003,      # 0.30%
        'gemini': 0.002,        # 0.20%
        'binance': 0.001,       # 0.10%
        'bybit': 0.0002,        # 0.02%
    })

    # === EXECUTION ===
    position_size_btc: float = 0.01     # Small size for HFT
    max_positions: int = 10             # Multiple arb opportunities
    symbol: str = 'BTC/USD'             # Trading pair

    # === SLIPPAGE ===
    max_slippage_pct: float = 0.05      # 5 bps max slippage per side

    # === SAFETY ===
    paper_mode: bool = True             # MUST start paper
    require_both_fills: bool = True     # Arb requires both sides to fill

    # === TIMING ===
    poll_interval_ms: int = 100         # Price poll interval
    stale_price_ms: int = 1000          # Max age of usable price

    # === PER-EXCHANGE LEVERAGE (from official docs Dec 2024) ===
    exchange_leverage: Dict[str, int] = field(default_factory=lambda: {
        'mexc': 500,        # MEXC max 500x futures
        'binance': 125,     # Binance max 125x (20x new users)
        'bybit': 100,       # Bybit max 100x
        'kraken': 50,       # Kraken max 50x
        'coinbase': 10,     # Coinbase max 10x (US regulated)
        'gemini': 5,        # Gemini 5x US, 100x non-US
        'bitstamp': 10,     # Bitstamp 10x max
        'crypto.com': 20,   # Crypto.com max 20x
        'default': 10       # Conservative default
    })

    def get_leverage(self, exchange: str) -> int:
        """Get max leverage for exchange."""
        return self.exchange_leverage.get(exchange.lower(), self.exchange_leverage['default'])

    def get_taker_fee(self, exchange: str) -> float:
        """Get taker fee for exchange."""
        return self.taker_fees.get(exchange.lower(), 0.005)  # Default 0.5%

    def get_maker_fee(self, exchange: str) -> float:
        """Get maker fee for exchange."""
        return self.maker_fees.get(exchange.lower(), 0.003)  # Default 0.3%

    def get_total_cost(self, buy_exchange: str, sell_exchange: str) -> float:
        """
        Calculate total cost for arbitrage trade.

        Cost = buy_fee + sell_fee + slippage_both_sides
        """
        buy_fee = self.get_taker_fee(buy_exchange)
        sell_fee = self.get_taker_fee(sell_exchange)
        slippage = self.max_slippage_pct * 2  # Both sides

        return buy_fee + sell_fee + slippage

    def is_profitable(self, spread_pct: float, buy_exchange: str, sell_exchange: str) -> bool:
        """
        Check if spread is profitable after all costs.

        Deterministic: Returns True only if GUARANTEED profit.
        """
        total_cost = self.get_total_cost(buy_exchange, sell_exchange)
        return spread_pct > total_cost


# Singleton config
_CONFIG = None


def get_config() -> HQTConfig:
    """Get HQT configuration singleton."""
    global _CONFIG
    if _CONFIG is None:
        _CONFIG = HQTConfig()
    return _CONFIG
