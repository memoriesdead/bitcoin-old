"""
Shared Utilities for All Strategies
====================================

Common components used by DET, HQT, and SCT strategies.
"""

from bitcoin.strategies.shared.leverage import (
    EXCHANGE_LEVERAGE,
    get_leverage,
    get_max_leverage_exchange
)
from bitcoin.strategies.shared.fees import (
    TAKER_FEES,
    MAKER_FEES,
    get_taker_fee,
    get_maker_fee,
    get_total_cost
)

__all__ = [
    'EXCHANGE_LEVERAGE',
    'get_leverage',
    'get_max_leverage_exchange',
    'TAKER_FEES',
    'MAKER_FEES',
    'get_taker_fee',
    'get_maker_fee',
    'get_total_cost',
]
