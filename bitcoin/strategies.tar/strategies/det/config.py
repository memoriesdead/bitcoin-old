"""
DET Strategy Configuration
==========================

100% Deterministic - ALL-IN or ALL-OUT
"""

from dataclasses import dataclass, field
from typing import Dict


@dataclass
class DETConfig:
    """DET Strategy Configuration."""

    # Entry criteria - ALL must be true for 100% win rate
    min_sample_count: int = 10           # Statistical significance
    min_correlation: float = 0.70        # 70%+ correlation with price
    min_win_rate: float = 0.90           # 90%+ historical accuracy

    # Position management
    position_size_pct: float = 0.25      # 25% of capital per position
    max_positions: int = 4               # Max concurrent positions

    # Exit strategy - time-based
    exit_timeout_seconds: float = 300.0  # 5 minute exit
    stop_loss_pct: float = 0.01          # 1% stop loss
    take_profit_pct: float = 0.02        # 2% take profit

    # Per-exchange max leverage (from official docs Dec 2024)
    exchange_leverage: Dict[str, int] = field(default_factory=lambda: {
        'mexc': 500,
        'binance': 125,
        'bybit': 100,
        'kraken': 50,
        'crypto.com': 20,
        'coinbase': 10,
        'bitstamp': 10,
        'gemini': 5,
        'default': 10
    })

    def get_leverage(self, exchange: str) -> int:
        """Get max leverage for exchange."""
        return self.exchange_leverage.get(exchange.lower(), self.exchange_leverage['default'])

    def validate_signal(self, sample_count: int, correlation: float, win_rate: float) -> bool:
        """
        Validate if signal meets 100% win rate criteria.

        Returns True ONLY if ALL criteria met.
        """
        return (
            sample_count >= self.min_sample_count and
            correlation >= self.min_correlation and
            win_rate >= self.min_win_rate
        )


# Global config instance
DET_CONFIG = DETConfig()
